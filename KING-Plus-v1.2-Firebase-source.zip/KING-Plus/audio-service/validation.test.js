import test from 'node:test';
import assert from 'node:assert/strict';
import { validRoom, safeName } from './validation.js';

test('room IDs are bounded and do not contain path separators', () => {
  assert.equal(validRoom('room_123'), true);
  assert.equal(validRoom('../room'), false);
  assert.equal(validRoom('a'), false);
  assert.equal(validRoom('a'.repeat(65)), false);
});
test('participant names are shortened', () => {
  assert.equal(safeName('  Ava  '), 'Ava');
  assert.equal(safeName('x'.repeat(80)).length, 60);
});
