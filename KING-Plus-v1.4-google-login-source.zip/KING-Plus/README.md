# KING Plus Android v1.3 — Firebase phone login prototype

Open this folder in Android Studio with JDK 17 and Android SDK 35. The project uses Android Gradle Plugin 8.7.3. A Gradle wrapper is not included.

Working on one device: local name and profile picture, a generated device ID, text and gallery-photo posts, post timestamps, editing, removal, local likes and comments, Android share sheet, post and room search, user-created rooms with removal, microphone permission and sound-level test, and confirmed deletion of all local app data. Data is stored in app preferences; photo references are retained through Android's document picker. The ID is not an account ID.

Firebase Phone Authentication now requests an SMS code and signs in with the verified credential. Firebase must have Phone enabled. A real device test is still required. Google and Facebook sign-in, hosted posts and profiles, cross-device sync, messaging, notifications, live audio, moderation and server-side deletion remain unimplemented. The existing posts, rooms, name and photos are stored locally on this device; local content is not isolated per signed-in account. Do not use the prototype for private user content or production accounts.

The previous Firebase v1.2 archive was compiled in GitHub Actions. This phone-login update requires a fresh build and on-device SMS test.

## APK build

The included `.github/workflows/android-debug.yml` builds a debug APK on a GitHub Actions runner when this project is placed at the repository root and pushed to `main` or `master`, or the workflow is run manually. Download `KING-Plus-debug-apk` from the completed run's Artifacts section. The APK is a debug build, not a signed production release. The workflow has not been run in this environment.

## Online integration inputs

To complete online accounts and social features, supply an owned backend project and configured Google/Facebook/phone sign-in providers; storage and database access rules; a real-time audio provider project; and production privacy/terms information. Keep credentials out of this source ZIP and configure them through the deployment environment. No online account or cross-device feature is implemented in this local prototype.

## Audio service project

`audio-service/` contains a separate Firebase-verified LiveKit token endpoint and its own setup instructions. It is not yet connected to the Android UI because this app has no Firebase sign-in or project configuration. The existing microphone meter remains a local-only test. The server keeps API secrets off the phone and issues 15-minute microphone-only grants.

## v1.4 sign-in
Google sign-in and first-time Firebase account creation use Android Credential Manager. The Google provider and OAuth client in the updated google-services.json must remain configured in Firebase. SMS login requires Firebase billing for real sends in this project. Facebook login is shown as unavailable until a Meta developer app is connected (App ID and Secret in Firebase; Android SDK configuration). No Facebook token is requested or accepted yet.
