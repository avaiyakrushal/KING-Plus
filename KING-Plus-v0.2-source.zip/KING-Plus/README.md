# KING Plus Android v0.2

Open this folder in Android Studio, sync Gradle, and run the `app` configuration. The project uses Android Gradle Plugin 8.7.3, JDK 17 and Android SDK 35. A Gradle wrapper is not included.

Included: name entry stored locally on the device, refreshed home and room screens, persistent locally created rooms, editable profile and sign out, microphone permission and a local sound-level meter. The meter only tests the device microphone; it does not send audio to anyone.

Not yet connected: Google sign-in, cloud accounts, shared rooms, online users, live multi-user voice, messaging, and gifts. These require an identity provider, backend and real-time audio service. Do not use the local name screen as authentication.
