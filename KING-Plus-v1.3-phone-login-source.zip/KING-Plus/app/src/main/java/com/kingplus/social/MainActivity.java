package com.kingplus.social;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.text.DateFormat;
import java.util.Date;
import java.util.UUID;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    private static final int MIC_REQUEST = 21;
    private static final int PHOTO_REQUEST = 22;
    private static final int AVATAR_REQUEST = 23;
    private static final int NAVY = 0xff0c1026, CARD = 0xff1b2141, PURPLE = 0xff7146ec;
    private static final int MUTED = 0xffc6bfdf;
    private final ArrayList<String> rooms = new ArrayList<>();
    private static final String[] DEFAULT_ROOMS = {"Music & Friends", "KING Lounge", "Game Talk"};
    private final Handler handler = new Handler(Looper.getMainLooper());
    private LinearLayout page;
    private AudioRecord recorder;
    private Thread meterThread;
    private volatile boolean recording;
    private TextView meter;
    private String currentRoom;
    private String displayName;
    private String memberId;
    private String screen = "login";
    private Uri selectedPhoto;
    private ImageView photoPreview;
    private FirebaseAuth auth;
    private String verificationId;
    private PhoneAuthProvider.ForceResendingToken resendToken;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        auth = FirebaseAuth.getInstance();
        String ordered = getPreferences(0).getString("custom_rooms", null);
        if (ordered != null) {
            try {
                JSONArray saved = new JSONArray(ordered);
                for (int i = 0; i < saved.length(); i++) {
                    String name = saved.optString(i).trim();
                    if (!name.isEmpty() && !isDefaultRoom(name) && !rooms.contains(name)) rooms.add(name);
                }
            } catch (Exception ignored) { }
        } else {
            Set<String> legacy = getPreferences(0).getStringSet("rooms", new HashSet<>());
            for (String name : legacy) if (!isDefaultRoom(name) && !rooms.contains(name)) rooms.add(name);
            saveRooms();
        }
        for (String name : DEFAULT_ROOMS) rooms.add(name);
        displayName = getPreferences(0).getString("name", "");
        memberId = getPreferences(0).getString("member_id", "");
        if (memberId.isEmpty()) {
            memberId = UUID.randomUUID().toString();
            getPreferences(0).edit().putString("member_id", memberId).apply();
        }
        if (auth.getCurrentUser() == null) login(); else authenticatedHome();
    }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable background(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private void base(String title, String subtitle) {
        stopMic();
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(NAVY);
        page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(30), dp(22), dp(36)); scroll.addView(page); setContentView(scroll);
        text(title, 29, Color.WHITE, true);
        if (subtitle != null) text(subtitle, 15, MUTED, false);
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setPadding(dp(3), dp(10), dp(3), dp(12)); page.addView(t); return t;
    }
    private void button(String title, int color, Runnable action) {
        Button b = new Button(this); b.setText(title); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setTextSize(16); b.setBackground(background(color, 18));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(56)); p.setMargins(0, dp(7), 0, dp(7));
        page.addView(b, p); b.setOnClickListener(v -> action.run());
    }
    private EditText input(String hint, String value) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setHint(hint); e.setText(value);
        e.setTextColor(Color.WHITE); e.setHintTextColor(MUTED); e.setPadding(dp(16), 0, dp(16), 0);
        e.setBackground(background(CARD, 15));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(56)); p.setMargins(0, dp(16), 0, dp(12));
        page.addView(e, p); return e;
    }
    private void login() {
        screen = "login"; base("👑 KING Plus", "તમારા મોબાઇલ નંબરથી સાઇન ઇન કરો");
        text("દેશના કોડ સાથે નંબર લખો (ઉદાહરણ: +91...)", 16, Color.WHITE, true);
        EditText phone = input("+91 મોબાઇલ નંબર", "");
        phone.setInputType(android.text.InputType.TYPE_CLASS_PHONE);
        button("SMS કોડ મોકલો", PURPLE, () -> {
            String number = phone.getText().toString().replaceAll("[\\s-]", "");
            if (!number.matches("\\+[1-9][0-9]{7,14}")) {
                phone.setError("દેશના કોડ સાથે સાચો નંબર લખો"); return;
            }
            requestPhoneCode(number, false);
        });
        text("Firebase નંબર ચકાસવા SMS મોકલશે. SMS દર અને મર્યાદા લાગુ પડી શકે છે.", 14, MUTED, false);
    }
    private void requestPhoneCode(String number, boolean resend) {
        base("SMS ચકાસણી", "કૃપા કરીને રાહ જુઓ...");
        PhoneAuthOptions.Builder options = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(number).setTimeout(60L, TimeUnit.SECONDS).setActivity(this)
            .setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                @Override public void onVerificationCompleted(PhoneAuthCredential credential) {
                    signInWithPhone(credential);
                }
                @Override public void onVerificationFailed(FirebaseException error) {
                    Toast.makeText(MainActivity.this, "SMS ચકાસણી નિષ્ફળ: " + error.getLocalizedMessage(), Toast.LENGTH_LONG).show();
                    login();
                }
                @Override public void onCodeSent(String id, PhoneAuthProvider.ForceResendingToken token) {
                    verificationId = id; resendToken = token; showCodeEntry(number);
                }
            });
        if (resend && resendToken != null) options.setForceResendingToken(resendToken);
        PhoneAuthProvider.verifyPhoneNumber(options.build());
    }
    private void showCodeEntry(String number) {
        screen = "otp"; base("SMS કોડ", number + " પર આવેલો 6 આંકડાનો કોડ લખો");
        EditText code = input("6 આંકડાનો કોડ", "");
        code.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        button("ચકાસો અને પ્રવેશ કરો", PURPLE, () -> {
            String value = code.getText().toString().trim();
            if (!value.matches("[0-9]{6}")) { code.setError("6 આંકડા લખો"); return; }
            if (verificationId == null) { login(); return; }
            signInWithPhone(PhoneAuthProvider.getCredential(verificationId, value));
        });
        button("કોડ ફરી મોકલો", CARD, () -> requestPhoneCode(number, true));
        button("નંબર બદલો", CARD, this::login);
    }
    private void signInWithPhone(PhoneAuthCredential credential) {
        auth.signInWithCredential(credential).addOnCompleteListener(this, task -> {
            if (task.isSuccessful()) authenticatedHome();
            else Toast.makeText(this, "કોડ ચકાસી શકાયો નથી: " +
                (task.getException() == null ? "ફરી પ્રયાસ કરો" : task.getException().getLocalizedMessage()),
                Toast.LENGTH_LONG).show();
        });
    }
    private void authenticatedHome() {
        FirebaseUser user = auth.getCurrentUser();
        if (user == null) { login(); return; }
        memberId = user.getUid();
        String savedUid = getPreferences(0).getString("profile_uid", "");
        if (!user.getUid().equals(savedUid)) {
            displayName = "";
            getPreferences(0).edit().putString("profile_uid", user.getUid()).remove("name").apply();
        }
        if (displayName.isEmpty()) chooseName(); else home();
    }
    private void chooseName() {
        screen = "name"; base("તમારું નામ", "આ નામ આ ફોનમાં સાચવાશે");
        EditText name = input("તમારું નામ", "");
        button("આગળ વધો", PURPLE, () -> {
            String value = name.getText().toString().trim();
            if (value.isEmpty()) { name.setError("નામ લખો"); return; }
            displayName = value;
            getPreferences(0).edit().putString("name", value).apply(); home();
        });
    }
    private void home() { home(""); }
    private void home(String query) {
        screen = "home"; base("👑 KING Plus", "નમસ્તે, " + displayName + " 👋");
        showAvatar(dp(72));
        button("+ નવી પોસ્ટ", PURPLE, this::composePost);
        button("🔎 પોસ્ટ અને રૂમ શોધો", CARD, this::searchHome);
        if (!query.isEmpty()) text("શોધ: " + query, 15, MUTED, false);
        text("મિત્રોની પોસ્ટ", 22, Color.WHITE, true);
        showPosts(query);
        button("+ નવો રૂમ બનાવો", PURPLE, this::createRoom);
        text("વૉઇસ રૂમ", 22, Color.WHITE, true);
        int matchingRooms = 0;
        for (String room : rooms) if (matches(room, query)) {
            button("🎙  " + room + "   →", CARD, () -> room(room)); matchingRooms++;
        }
        if (matchingRooms == 0) text("આ નામનો રૂમ મળ્યો નથી", 14, MUTED, false);
        if (!query.isEmpty()) button("બધું બતાવો", CARD, this::home);
        button("મારી પ્રોફાઇલ", CARD, this::profile);
    }
    private boolean matches(String value, String query) {
        return value.toLowerCase(Locale.ROOT).contains(query.toLowerCase(Locale.ROOT));
    }
    private void searchHome() {
        EditText entry = new EditText(this); entry.setHint("શબ્દ લખો");
        LinearLayout wrap = new LinearLayout(this); wrap.setPadding(dp(20), 0, dp(20), 0); wrap.addView(entry);
        new AlertDialog.Builder(this).setTitle("શોધો").setView(wrap)
            .setNegativeButton("રદ કરો", null)
            .setPositiveButton("શોધો", (d, which) -> home(entry.getText().toString().trim())).show();
    }
    private void composePost() {
        screen = "compose"; selectedPhoto = null; base("નવી પોસ્ટ", "તમારી વાત અને ફોટો શેર કરો");
        EditText caption = input("શું ચાલી રહ્યું છે?", "");
        caption.setSingleLine(false); caption.setMinLines(3);
        button("ગેલેરીમાંથી ફોટો પસંદ કરો", CARD, () -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("image/*");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(intent, PHOTO_REQUEST);
        });
        photoPreview = new ImageView(this);
        photoPreview.setAdjustViewBounds(true);
        photoPreview.setMaxHeight(dp(260));
        page.addView(photoPreview, new LinearLayout.LayoutParams(-1, -2));
        button("પોસ્ટ સાચવો", PURPLE, () -> {
            String body = caption.getText().toString().trim();
            if (body.isEmpty() && selectedPhoto == null) { caption.setError("લખાણ અથવા ફોટો ઉમેરો"); return; }
            try {
                JSONArray posts = new JSONArray(getPreferences(0).getString("posts", "[]"));
                JSONObject post = new JSONObject();
                post.put("name", displayName); post.put("body", body);
                post.put("photo", selectedPhoto == null ? "" : selectedPhoto.toString());
                post.put("time", System.currentTimeMillis());
                JSONArray updated = new JSONArray(); updated.put(post);
                for (int i = 0; i < Math.min(posts.length(), 99); i++) updated.put(posts.get(i));
                getPreferences(0).edit().putString("posts", updated.toString()).apply();
                home();
            } catch (Exception ex) { Toast.makeText(this, "પોસ્ટ સાચવી શકાઈ નથી", Toast.LENGTH_SHORT).show(); }
        });
        button("પાછા જાઓ", CARD, this::home);
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == AVATAR_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri avatar = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(avatar, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                getPreferences(0).edit().putString("avatar", avatar.toString()).apply();
                profile();
            } catch (Exception ex) { Toast.makeText(this, "પ્રોફાઇલ ફોટો સાચવી શકાયો નથી", Toast.LENGTH_SHORT).show(); }
            return;
        }
        if (requestCode == PHOTO_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedPhoto = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(selectedPhoto, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                if (photoPreview != null) photoPreview.setImageURI(selectedPhoto);
            } catch (Exception ex) { selectedPhoto = null; Toast.makeText(this, "ફોટો ખોલી શકાતો નથી", Toast.LENGTH_SHORT).show(); }
        }
    }
    private void showPosts(String query) {
        try {
            JSONArray posts = new JSONArray(getPreferences(0).getString("posts", "[]"));
            if (posts.length() == 0) { text("હજુ કોઈ પોસ્ટ નથી. તમારી પહેલી પોસ્ટ બનાવો!", 15, MUTED, false); return; }
            int matchingPosts = 0;
            for (int i = 0; i < posts.length(); i++) {
                JSONObject post = posts.getJSONObject(i);
                if (!matches(post.optString("body") + " " + post.optString("name"), query)) continue;
                matchingPosts++;
                text("👤 " + post.optString("name", "સભ્ય"), 17, Color.WHITE, true);
                long created = post.optLong("time", 0);
                if (created > 0) text(DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
                    .format(new Date(created)), 13, MUTED, false);
                if (!post.optString("body").isEmpty()) text(post.optString("body"), 16, Color.WHITE, false);
                String photo = post.optString("photo");
                if (!photo.isEmpty()) {
                    ImageView picture = new ImageView(this);
                    picture.setAdjustViewBounds(true); picture.setMaxHeight(dp(360));
                    try { picture.setImageURI(Uri.parse(photo)); page.addView(picture, new LinearLayout.LayoutParams(-1, -2)); }
                    catch (Exception ignored) { text("ફોટો ઉપલબ્ધ નથી", 14, MUTED, false); }
                }
                final int index = i;
                boolean liked = post.optBoolean("liked", false);
                int likes = post.optInt("likes", 0);
                button((liked ? "♥" : "♡") + " લાઈક  " + likes, CARD, () -> updatePost(index, "like", null));
                JSONArray comments = post.optJSONArray("comments");
                if (comments != null) for (int j = 0; j < comments.length(); j++) {
                    JSONObject comment = comments.optJSONObject(j);
                    if (comment != null) text("💬 " + comment.optString("name") + ": " + comment.optString("body"), 14, MUTED, false);
                }
                button("કમેન્ટ લખો", CARD, () -> commentOnPost(index));
                button("પોસ્ટ શેર કરો", CARD, () -> sharePost(post));
                button("પોસ્ટનું લખાણ બદલો", CARD, () -> editPost(index, post));
                button("આ પોસ્ટ કાઢો", CARD, () -> new AlertDialog.Builder(this)
                    .setMessage("આ પોસ્ટ કાઢવી છે?").setNegativeButton("રદ કરો", null)
                    .setPositiveButton("કાઢો", (d, which) -> updatePost(index, "delete", null)).show());
                text("──────────────", 14, MUTED, false);
            }
            if (matchingPosts == 0) text("આ શોધમાં કોઈ પોસ્ટ મળી નથી", 14, MUTED, false);
        } catch (Exception ex) { text("પોસ્ટ લોડ થઈ શકી નથી", 14, MUTED, false); }
    }
    private void editPost(int index, JSONObject post) {
        EditText entry = new EditText(this); entry.setText(post.optString("body"));
        entry.setSingleLine(false); entry.setMinLines(3);
        LinearLayout wrap = new LinearLayout(this); wrap.setPadding(dp(20), 0, dp(20), 0); wrap.addView(entry);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("પોસ્ટનું લખાણ")
            .setView(wrap).setNegativeButton("રદ કરો", null).setPositiveButton("સાચવો", null).create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(w -> {
            String value = entry.getText().toString().trim();
            if (value.isEmpty() && post.optString("photo").isEmpty()) {
                entry.setError("લખાણ અથવા ફોટો જરૂરી છે"); return;
            }
            updatePost(index, "edit", value); dialog.dismiss();
        })); dialog.show();
    }
    private void sharePost(JSONObject post) {
        try {
            String body = post.optString("body").trim();
            String caption = post.optString("name", "KING Plus") + " • KING Plus";
            String photo = post.optString("photo");
            Intent send = new Intent(Intent.ACTION_SEND);
            if (photo.isEmpty()) {
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_TEXT, caption + "\n" + body);
            } else {
                send.setType("image/*");
                Uri uri = Uri.parse(photo);
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.putExtra(Intent.EXTRA_TEXT, caption + (body.isEmpty() ? "" : "\n" + body));
                send.setClipData(android.content.ClipData.newRawUri("KING Plus photo", uri));
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            }
            startActivity(Intent.createChooser(send, "પોસ્ટ શેર કરો"));
        } catch (Exception ex) { Toast.makeText(this, "આ પોસ્ટ શેર કરી શકાતી નથી", Toast.LENGTH_SHORT).show(); }
    }
    private void commentOnPost(int index) {
        EditText entry = new EditText(this); entry.setHint("કમેન્ટ લખો");
        LinearLayout wrap = new LinearLayout(this); wrap.setPadding(dp(20), 0, dp(20), 0); wrap.addView(entry);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("કમેન્ટ")
            .setView(wrap).setNegativeButton("રદ કરો", null).setPositiveButton("મોકલો", null).create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(w -> {
            String value = entry.getText().toString().trim();
            if (value.isEmpty()) { entry.setError("કમેન્ટ લખો"); return; }
            updatePost(index, "comment", value); dialog.dismiss();
        })); dialog.show();
    }
    private void updatePost(int index, String action, String value) {
        try {
            JSONArray posts = new JSONArray(getPreferences(0).getString("posts", "[]"));
            if (index < 0 || index >= posts.length()) return;
            JSONObject post = posts.getJSONObject(index);
            if ("like".equals(action)) {
                boolean liked = post.optBoolean("liked", false);
                post.put("liked", !liked);
                post.put("likes", Math.max(0, post.optInt("likes", 0) + (liked ? -1 : 1)));
            } else if ("comment".equals(action)) {
                JSONArray comments = post.optJSONArray("comments");
                if (comments == null) comments = new JSONArray();
                comments.put(new JSONObject().put("name", displayName).put("body", value));
                post.put("comments", comments);
            } else if ("edit".equals(action)) {
                post.put("body", value);
            }
            JSONArray updated = new JSONArray();
            for (int i = 0; i < posts.length(); i++) if (!("delete".equals(action) && i == index)) updated.put(posts.get(i));
            getPreferences(0).edit().putString("posts", updated.toString()).apply(); home();
        } catch (Exception ex) { Toast.makeText(this, "ફેરફાર સાચવી શકાયો નથી", Toast.LENGTH_SHORT).show(); }
    }
    private void createRoom() {
        EditText e = new EditText(this); e.setSingleLine(true); e.setHint("રૂમનું નામ");
        LinearLayout wrap = new LinearLayout(this); wrap.setPadding(dp(20), 0, dp(20), 0); wrap.addView(e);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("નવો રૂમ").setView(wrap)
            .setNegativeButton("રદ કરો", null).setPositiveButton("બનાવો", null).create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(w -> {
            String name = e.getText().toString().trim();
            if (name.isEmpty()) { e.setError("રૂમનું નામ લખો"); return; }
            if (rooms.contains(name)) { e.setError("આ નામનો રૂમ પહેલેથી છે"); return; }
            rooms.add(0, name);
            saveRooms();
            dialog.dismiss(); room(name);
        })); dialog.show();
    }
    private void room(String name) {
        screen = "room"; currentRoom = name;
        base("🎙 " + name, "તમારો માઇક તપાસો");
        text("સભ્ય: " + displayName, 18, Color.WHITE, true);
        meter = text("માઇક બંધ છે", 18, MUTED, false);
        button("માઇક ટેસ્ટ શરૂ કરો", PURPLE, this::requestMic);
        button("માઇક બંધ કરો", CARD, () -> { stopMic(); if (meter != null) meter.setText("માઇક બંધ છે"); });
        if (!isDefaultRoom(name)) button("આ રૂમ કાઢો", CARD, () -> new AlertDialog.Builder(this)
            .setMessage("આ ફોનમાંથી રૂમ કાઢવો છે?").setNegativeButton("રદ કરો", null)
            .setPositiveButton("કાઢો", (d, which) -> { stopMic(); rooms.remove(name); saveRooms(); home(); }).show());
        text("માઇક ટેસ્ટ ફક્ત આ ફોન પર અવાજનું સ્તર બતાવે છે. બીજા લોકો સુધી અવાજ પહોંચાડવા લાઇવ વૉઇસ સેવા જોડવી પડશે.", 14, MUTED, false);
        button("રૂમમાંથી બહાર નીકળો", CARD, this::home);
    }
    private boolean isDefaultRoom(String name) {
        for (String item : DEFAULT_ROOMS) if (item.equals(name)) return true;
        return false;
    }
    private void saveRooms() {
        JSONArray saved = new JSONArray();
        for (String name : rooms) if (!isDefaultRoom(name)) saved.put(name);
        getPreferences(0).edit().putString("custom_rooms", saved.toString()).remove("rooms").apply();
    }
    private void requestMic() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQUEST); return;
        }
        startMic();
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == MIC_REQUEST && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED && "room".equals(screen)) startMic();
        else if (requestCode == MIC_REQUEST) Toast.makeText(this, "માઇક પરવાનગી જરૂરી છે", Toast.LENGTH_SHORT).show();
    }
    private void startMic() {
        stopMic();
        int rate = 16000;
        int min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        if (min <= 0) { Toast.makeText(this, "માઇક ઉપલબ્ધ નથી", Toast.LENGTH_SHORT).show(); return; }
        try {
            recorder = new AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, Math.max(min, 2048));
            if (recorder.getState() != AudioRecord.STATE_INITIALIZED) { stopMic(); return; }
            recorder.startRecording(); recording = true;
            if (meter != null) meter.setText("માઇક ચાલુ છે • બોલીને તપાસો");
            AudioRecord source = recorder;
            meterThread = new Thread(() -> {
                short[] samples = new short[1024];
                while (recording) {
                    int count = source.read(samples, 0, samples.length);
                    if (count <= 0) break;
                    long sum = 0;
                    for (int i = 0; i < count; i++) sum += Math.abs((int)samples[i]);
                    int level = (int)Math.min(10, (sum / count) / 1800);
                    handler.post(() -> { if (recording && meter != null) meter.setText("માઇક ચાલુ છે  " + bars(level)); });
                }
            }); meterThread.start();
        } catch (Exception ex) { stopMic(); Toast.makeText(this, "માઇક શરૂ થઈ શક્યો નથી", Toast.LENGTH_SHORT).show(); }
    }
    private void stopMic() {
        recording = false;
        if (recorder != null) {
            try { recorder.stop(); } catch (Exception ignored) { }
            recorder.release(); recorder = null;
        }
        meterThread = null;
    }
    private String bars(int level) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < 10; i++) result.append(i < level ? '▮' : '▯');
        return result.toString();
    }
    private void profile() {
        screen = "profile"; base("મારી પ્રોફાઇલ", "KING Plus સભ્ય");
        showAvatar(dp(140));
        text("👑  " + displayName, 24, Color.WHITE, true);
        text("આ ફોનની ઓળખ: " + memberId.substring(0, 8), 14, MUTED, false);
        button("પ્રોફાઇલ ફોટો પસંદ કરો", PURPLE, () -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("image/*");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(intent, AVATAR_REQUEST);
        });
        if (!getPreferences(0).getString("avatar", "").isEmpty())
            button("પ્રોફાઇલ ફોટો દૂર કરો", CARD, () -> {
                getPreferences(0).edit().remove("avatar").apply(); profile();
            });
        button("નામ બદલો", PURPLE, () -> {
            EditText e = new EditText(this); e.setText(displayName);
            new AlertDialog.Builder(this).setTitle("તમારું નામ").setView(e).setNegativeButton("રદ કરો", null)
                .setPositiveButton("સાચવો", (d, which) -> {
                    String value = e.getText().toString().trim();
                    if (!value.isEmpty()) { displayName = value; getPreferences(0).edit().putString("name", value).apply(); profile(); }
                }).show();
        });
        button("આ ફોનમાંથી સાઇન આઉટ", CARD, () -> new AlertDialog.Builder(this).setMessage("આ ફોનમાંથી પ્રોફાઇલ દૂર કરવી છે?")
            .setNegativeButton("રદ કરો", null).setPositiveButton("દૂર કરો", (d, which) -> {
                auth.signOut(); getPreferences(0).edit().remove("name").remove("avatar").remove("profile_uid").apply(); displayName = ""; login();
            }).show());
        button("આ ફોનનો બધો એપ ડેટા કાઢો", CARD, () -> new AlertDialog.Builder(this)
            .setTitle("બધો સ્થાનિક ડેટા કાઢો")
            .setMessage("પોસ્ટ, કમેન્ટ, રૂમ અને પ્રોફાઇલ આ ફોનમાંથી કાયમ માટે દૂર થશે.")
            .setNegativeButton("રદ કરો", null)
            .setPositiveButton("બધું કાઢો", (d, which) -> {
                stopMic(); getPreferences(0).edit().clear().commit();
                rooms.clear(); for (String item : DEFAULT_ROOMS) rooms.add(item);
                memberId = UUID.randomUUID().toString();
                getPreferences(0).edit().putString("member_id", memberId).apply();
                auth.signOut(); displayName = ""; login();
            }).show());
        button("પાછા જાઓ", CARD, this::home);
    }
    private void showAvatar(int size) {
        String saved = getPreferences(0).getString("avatar", "");
        if (saved.isEmpty()) return;
        ImageView avatar = new ImageView(this);
        avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(size, size);
        params.setMargins(0, dp(8), 0, dp(8));
        try { avatar.setImageURI(Uri.parse(saved)); page.addView(avatar, params); }
        catch (Exception ex) { getPreferences(0).edit().remove("avatar").apply(); }
    }
    @Override public void onBackPressed() {
        if ("login".equals(screen) || "home".equals(screen)) super.onBackPressed();
        else if ("otp".equals(screen)) login();
        else if ("name".equals(screen)) chooseName();
        else home();
    }
    @Override protected void onPause() { super.onPause(); stopMic(); }
    @Override protected void onDestroy() { stopMic(); super.onDestroy(); }
}
