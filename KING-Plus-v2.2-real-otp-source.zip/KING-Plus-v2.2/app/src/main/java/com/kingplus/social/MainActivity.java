package com.kingplus.social;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.text.InputType;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int MIC_REQUEST = 21;
    private static final int PHOTO_REQUEST = 22;
    private static final int GOOGLE_SIGN_IN_REQUEST = 23;
    private static final int NAVY = 0xff0c1026, CARD = 0xff1b2141, PURPLE = 0xff7146ec;
    private static final int MUTED = 0xffc6bfdf;
    private final ArrayList<String> rooms = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private LinearLayout page;
    private AudioRecord recorder;
    private Thread meterThread;
    private volatile boolean recording;
    private TextView meter;
    private String currentRoom;
    private String displayName;
    private String screen = "login";
    private Uri selectedPhoto;
    private ImageView photoPreview;
    private int mySeat = 1;
    private boolean roomLocked = false;
    private String roomAnnouncement = "Welcome to KING Plus • Be friendly and have fun";
    private int coinBalance = 2500;
    private int giftCount = 0;
    private int receivedGiftCount = 0;
    private FirebaseAuth firebaseAuth;
    private GoogleSignInClient googleSignInClient;
    private String phoneVerificationId;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        rooms.add("Music & Friends"); rooms.add("KING Lounge"); rooms.add("Game Talk");
        Set<String> saved = getPreferences(0).getStringSet("rooms", new HashSet<>());
        for (String name : saved) if (!rooms.contains(name)) rooms.add(0, name);
        displayName = getPreferences(0).getString("name", "");
        coinBalance = getPreferences(0).getInt("coins", 2500);
        giftCount = getPreferences(0).getInt("gift_count", 0);
        receivedGiftCount = getPreferences(0).getInt("received_gifts", 0);
        try {
            FirebaseApp app = FirebaseApp.initializeApp(this);
            if (app != null) firebaseAuth = FirebaseAuth.getInstance();
        } catch (Exception ignored) { firebaseAuth = null; }
        if (displayName.isEmpty()) login(); else home();
    }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable background(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private void base(String title, String subtitle) {
        stopMic();
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(NAVY);
        page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(30), dp(22), dp(36)); scroll.addView(page); setContentView(scroll);
        text(title, 29, Color.WHITE, true);
        if (subtitle != null) text(subtitle, 15, MUTED, false);
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setPadding(dp(3), dp(10), dp(3), dp(12)); page.addView(t); return t;
    }
    private void button(String title, int color, Runnable action) {
        Button b = new Button(this); b.setText(title); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setTextSize(16); b.setBackground(background(color, 18));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(56)); p.setMargins(0, dp(7), 0, dp(7));
        page.addView(b, p); b.setOnClickListener(v -> action.run());
    }
    private EditText input(String hint, String value) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setHint(hint); e.setText(value);
        e.setTextColor(Color.WHITE); e.setHintTextColor(MUTED); e.setPadding(dp(16), 0, dp(16), 0);
        e.setBackground(background(CARD, 15));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(56)); p.setMargins(0, dp(16), 0, dp(12));
        page.addView(e, p); return e;
    }
    private void login() {
        screen = "login"; base("👑 KING Plus", "Login or create your account");
        text("Welcome", 23, Color.WHITE, true);
        text("Choose a sign-in method", 14, MUTED, false);
        button("G  Continue with Google", 0xff4285f4, this::googleLogin);
        button("f  Continue with Facebook", 0xff1877f2, () -> socialProviderSetupRequired("Facebook"));
        button("📱  Continue with Mobile Number", PURPLE, this::mobileLogin);
        text("Terms & Privacy  •  Trouble logging in?", 13, MUTED, false);
        text("Mobile login now uses Firebase SMS OTP. Google login is Firebase-ready. Facebook still needs Meta App credentials.", 12, MUTED, false);
    }
    private void socialProviderSetupRequired(String provider) {
        new AlertDialog.Builder(this).setTitle(provider + " sign-in")
            .setMessage(provider + " login needs the provider App ID/secret and Firebase provider setup. No fake local login is used here.")
            .setPositiveButton("OK", null).show();
    }
    private boolean ensureFirebaseReady() {
        if (firebaseAuth != null) return true;
        new AlertDialog.Builder(this).setTitle("Firebase setup required")
            .setMessage("Add google-services.json to the app/ folder, enable Authentication in Firebase, then rebuild the app.")
            .setPositiveButton("OK", null).show();
        return false;
    }
    private void googleLogin() {
        if (!ensureFirebaseReady()) return;
        int id = getResources().getIdentifier("default_web_client_id", "string", getPackageName());
        if (id == 0) {
            new AlertDialog.Builder(this).setTitle("Google login setup")
                .setMessage("default_web_client_id was not generated. Check google-services.json and enable Google under Firebase Authentication > Sign-in method.")
                .setPositiveButton("OK", null).show();
            return;
        }
        String webClientId = getString(id);
        GoogleSignInOptions options = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(webClientId).requestEmail().build();
        googleSignInClient = GoogleSignIn.getClient(this, options);
        startActivityForResult(googleSignInClient.getSignInIntent(), GOOGLE_SIGN_IN_REQUEST);
    }
    private void firebaseAuthWithGoogle(String idToken, String fallbackName) {
        AuthCredential credential = GoogleAuthProvider.getCredential(idToken, null);
        firebaseAuth.signInWithCredential(credential).addOnCompleteListener(this, task -> {
            if (!task.isSuccessful()) {
                Toast.makeText(this, "Google sign-in failed: " + (task.getException() == null ? "Unknown error" : task.getException().getMessage()), Toast.LENGTH_LONG).show();
                return;
            }
            FirebaseUser user = firebaseAuth.getCurrentUser();
            String name = user != null && user.getDisplayName() != null && !user.getDisplayName().trim().isEmpty() ? user.getDisplayName() : fallbackName;
            saveLocalSession(name, "Google");
        });
    }
    private void mobileLogin() {
        if (!ensureFirebaseReady()) return;
        final EditText phone = new EditText(this);
        phone.setHint("Mobile number, e.g. +919876543210"); phone.setSingleLine(true); phone.setInputType(InputType.TYPE_CLASS_PHONE);
        new AlertDialog.Builder(this).setTitle("Mobile login").setView(phone).setNegativeButton("Cancel", null)
            .setPositiveButton("Send OTP", (d,w) -> {
                String number = normalizePhone(phone.getText().toString());
                if (number == null) { Toast.makeText(this, "Enter a valid mobile number", Toast.LENGTH_SHORT).show(); return; }
                sendRealOtp(number);
            }).show();
    }
    private String normalizePhone(String raw) {
        if (raw == null) return null;
        String n = raw.replaceAll("[\\s()-]", "");
        if (n.matches("[0-9]{10}")) n = "+91" + n;
        if (!n.matches("\\+[0-9]{10,15}")) return null;
        return n;
    }
    private void sendRealOtp(String number) {
        PhoneAuthOptions options = PhoneAuthOptions.newBuilder(firebaseAuth)
            .setPhoneNumber(number)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(this)
            .setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                @Override public void onVerificationCompleted(PhoneAuthCredential credential) { signInWithPhoneCredential(credential, number); }
                @Override public void onVerificationFailed(com.google.firebase.FirebaseException e) {
                    Toast.makeText(MainActivity.this, "OTP failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
                @Override public void onCodeSent(String verificationId, PhoneAuthProvider.ForceResendingToken token) {
                    phoneVerificationId = verificationId;
                    Toast.makeText(MainActivity.this, "OTP sent", Toast.LENGTH_SHORT).show();
                    showOtpDialog(number);
                }
            }).build();
        PhoneAuthProvider.verifyPhoneNumber(options);
    }
    private void showOtpDialog(String number) {
        final EditText otp = new EditText(this); otp.setHint("6-digit OTP"); otp.setSingleLine(true);
        otp.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        new AlertDialog.Builder(this).setTitle("Verify " + number).setMessage("Enter the SMS OTP sent by Firebase.")
            .setView(otp).setNegativeButton("Cancel", null).setPositiveButton("Verify", (d,w) -> {
                String code = otp.getText().toString().trim();
                if (phoneVerificationId == null || code.length() < 6) { Toast.makeText(this, "Enter the 6-digit OTP", Toast.LENGTH_SHORT).show(); return; }
                signInWithPhoneCredential(PhoneAuthProvider.getCredential(phoneVerificationId, code), number);
            }).show();
    }
    private void signInWithPhoneCredential(PhoneAuthCredential credential, String number) {
        firebaseAuth.signInWithCredential(credential).addOnCompleteListener(this, task -> {
            if (!task.isSuccessful()) {
                Toast.makeText(this, "OTP verification failed: " + (task.getException() == null ? "Invalid OTP" : task.getException().getMessage()), Toast.LENGTH_LONG).show();
                return;
            }
            String shortNumber = number.length() > 4 ? "KING " + number.substring(number.length() - 4) : "KING User";
            saveLocalSession(shortNumber, "Mobile");
        });
    }
    private void saveLocalSession(String name, String provider) {
        displayName=name; getPreferences(0).edit().putString("name",name).putString("login_provider",provider).apply(); home();
    }
    private void home() {
        screen = "home"; stopMic();
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(0xfff8f8fb);
        LinearLayout top = new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(dp(16), dp(12), dp(12), dp(8));
        TextView brand = new TextView(this); brand.setText("KING Plus"); brand.setTextSize(25); brand.setTextColor(0xff111111); brand.setTypeface(null, Typeface.BOLD); top.addView(brand, new LinearLayout.LayoutParams(0, dp(52), 1));
        TextView actions = new TextView(this); actions.setText("🔍   ⊕"); actions.setTextSize(25); actions.setGravity(Gravity.CENTER); actions.setOnClickListener(v -> new AlertDialog.Builder(this).setItems(new String[]{"🔍 Search","⊕ Create room","🔔 Notifications"},(d,w)->{if(w==0)searchCommunity();else if(w==1)createRoomDialog();else notificationsCenter();}).show()); top.addView(actions, new LinearLayout.LayoutParams(dp(92), dp(52))); root.addView(top);

        LinearLayout tabs = new LinearLayout(this); tabs.setGravity(Gravity.CENTER); tabs.setPadding(dp(8),0,dp(8),dp(7));
        String[] tabNames={"Hot","Event","Date","Music","Game"};
        for (int i=0;i<tabNames.length;i++){ TextView t=new TextView(this); t.setText(tabNames[i]); t.setTextSize(i==0?18:16); t.setTextColor(i==0?0xff8a43ff:0xff777777); t.setTypeface(null,i==0?Typeface.BOLD:Typeface.NORMAL); t.setGravity(Gravity.CENTER); final String tab=tabNames[i]; t.setOnClickListener(v -> Toast.makeText(this, tab+" rooms", Toast.LENGTH_SHORT).show()); tabs.addView(t,new LinearLayout.LayoutParams(0,dp(44),1)); }
        root.addView(tabs);

        ScrollView scroll = new ScrollView(this); LinearLayout content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(14),dp(6),dp(14),dp(18)); scroll.addView(content);
        TextView banner=new TextView(this); banner.setText("🎉  KING Plus Party\nMeet • Talk • Play"); banner.setTextSize(22); banner.setTextColor(Color.WHITE); banner.setTypeface(null,Typeface.BOLD); banner.setGravity(Gravity.CENTER_VERTICAL); banner.setPadding(dp(20),0,0,0); banner.setBackground(background(0xff7048e8,18)); content.addView(banner,new LinearLayout.LayoutParams(-1,dp(118)));
        if (rooms.size() > 3) {
            TextView mine=new TextView(this); mine.setText("👑  My rooms"); mine.setTextSize(19); mine.setTextColor(0xff222222); mine.setTypeface(null,Typeface.BOLD); mine.setPadding(0,dp(20),0,dp(8)); content.addView(mine);
            for (String roomName : rooms) {
                if (roomName.equals("Music & Friends") || roomName.equals("KING Lounge") || roomName.equals("Game Talk")) continue;
                TextView r=new TextView(this); r.setText("🎙  "+roomName+"    • Tap to join"); r.setTextSize(16); r.setTextColor(0xff222222); r.setPadding(dp(16),dp(15),dp(16),dp(15)); r.setBackground(background(Color.WHITE,16)); LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2); rp.setMargins(0,dp(4),0,dp(4)); content.addView(r,rp); r.setOnClickListener(v->room(roomName));
            }
        }
        TextView section=new TextView(this); section.setText("🔥  Popular rooms"); section.setTextSize(19); section.setTextColor(0xff222222); section.setTypeface(null,Typeface.BOLD); section.setPadding(0,dp(20),0,dp(12)); content.addView(section);
        String[][] data={{"🎤","Music & Friends","Music • 1.2K"},{"👑","KING Lounge","Chat • 856"},{"🎮","Game Talk","Games • 642"},{"💜","Friends Forever","Friends • 518"},{"🎵","Night Music","Music • 433"},{"✨","New Friends","Chat • 390"}};
        for(int r=0;r<3;r++){ LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); for(int c=0;c<2;c++){ String[] d=data[r*2+c]; LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(14),dp(14),dp(12),dp(12)); card.setBackground(background(0xffffffff,18)); TextView icon=new TextView(this); icon.setText(d[0]); icon.setTextSize(34); card.addView(icon,new LinearLayout.LayoutParams(-1,dp(52))); TextView name=new TextView(this); name.setText(d[1]); name.setTextSize(16); name.setTextColor(0xff222222); name.setTypeface(null,Typeface.BOLD); card.addView(name); TextView meta=new TextView(this); meta.setText(d[2]); meta.setTextSize(13); meta.setTextColor(0xff888888); meta.setPadding(0,dp(5),0,0); card.addView(meta); card.setOnClickListener(v->room(d[1])); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(142),1); cp.setMargins(c==0?0:dp(6),dp(5),c==0?dp(6):0,dp(5)); row.addView(card,cp);} content.addView(row,new LinearLayout.LayoutParams(-1,-2)); }
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,0,1); root.addView(scroll,sp);

        LinearLayout nav=new LinearLayout(this); nav.setGravity(Gravity.CENTER); nav.setPadding(dp(4),dp(4),dp(4),dp(7)); nav.setBackgroundColor(Color.WHITE);
        String[] ni={"⌂\nParty","♟\nGame","◇\nDiscover","✉\nMessages","●\nMe"};
        for(int i=0;i<ni.length;i++){ TextView n=new TextView(this); n.setText(ni[i]); n.setTextSize(12); n.setGravity(Gravity.CENTER); n.setTextColor(i==0?0xff8a43ff:0xff777777); final int idx=i; n.setOnClickListener(v->{ if(idx==4) profile(); else if(idx==1) games(); else if(idx==2) discover(); else if(idx==3) messages(); }); nav.addView(n,new LinearLayout.LayoutParams(0,dp(62),1)); } root.addView(nav);
        setContentView(root);
    }
    private void simplePage(String title, String message){ screen="sub"; base(title,null); text(message,18,Color.WHITE,true); button("પાછા Party પર જાઓ",PURPLE,this::home); }
    private void composePost() {
        screen = "compose"; selectedPhoto = null; base("નવી પોસ્ટ", "તમારી વાત અને ફોટો શેર કરો");
        EditText caption = input("શું ચાલી રહ્યું છે?", "");
        caption.setSingleLine(false); caption.setMinLines(3);
        button("ગેલેરીમાંથી ફોટો પસંદ કરો", CARD, () -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("image/*");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(intent, PHOTO_REQUEST);
        });
        photoPreview = new ImageView(this);
        photoPreview.setAdjustViewBounds(true);
        photoPreview.setMaxHeight(dp(260));
        page.addView(photoPreview, new LinearLayout.LayoutParams(-1, -2));
        button("પોસ્ટ સાચવો", PURPLE, () -> {
            String body = caption.getText().toString().trim();
            if (body.isEmpty() && selectedPhoto == null) { caption.setError("લખાણ અથવા ફોટો ઉમેરો"); return; }
            try {
                JSONArray posts = new JSONArray(getPreferences(0).getString("posts", "[]"));
                JSONObject post = new JSONObject();
                post.put("name", displayName); post.put("body", body);
                post.put("photo", selectedPhoto == null ? "" : selectedPhoto.toString());
                post.put("time", System.currentTimeMillis());
                JSONArray updated = new JSONArray(); updated.put(post);
                for (int i = 0; i < Math.min(posts.length(), 99); i++) updated.put(posts.get(i));
                getPreferences(0).edit().putString("posts", updated.toString()).apply();
                home();
            } catch (Exception ex) { Toast.makeText(this, "પોસ્ટ સાચવી શકાઈ નથી", Toast.LENGTH_SHORT).show(); }
        });
        button("પાછા જાઓ", CARD, this::home);
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GOOGLE_SIGN_IN_REQUEST) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                GoogleSignInAccount account = task.getResult(ApiException.class);
                if (account != null && account.getIdToken() != null) firebaseAuthWithGoogle(account.getIdToken(), account.getDisplayName() == null ? "Google User" : account.getDisplayName());
            } catch (ApiException e) { Toast.makeText(this, "Google sign-in cancelled/failed: " + e.getStatusCode(), Toast.LENGTH_LONG).show(); }
            return;
        }
        if (requestCode == PHOTO_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedPhoto = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(selectedPhoto, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                if (photoPreview != null) photoPreview.setImageURI(selectedPhoto);
            } catch (Exception ex) { selectedPhoto = null; Toast.makeText(this, "ફોટો ખોલી શકાતો નથી", Toast.LENGTH_SHORT).show(); }
        }
    }
    private void showPosts() {
        try {
            JSONArray posts = new JSONArray(getPreferences(0).getString("posts", "[]"));
            if (posts.length() == 0) { text("હજુ કોઈ પોસ્ટ નથી. તમારી પહેલી પોસ્ટ બનાવો!", 15, MUTED, false); return; }
            for (int i = 0; i < posts.length(); i++) {
                JSONObject post = posts.getJSONObject(i);
                text("👤 " + post.optString("name", "સભ્ય"), 17, Color.WHITE, true);
                if (!post.optString("body").isEmpty()) text(post.optString("body"), 16, Color.WHITE, false);
                String photo = post.optString("photo");
                if (!photo.isEmpty()) {
                    ImageView picture = new ImageView(this);
                    picture.setAdjustViewBounds(true); picture.setMaxHeight(dp(360));
                    try { picture.setImageURI(Uri.parse(photo)); page.addView(picture, new LinearLayout.LayoutParams(-1, -2)); }
                    catch (Exception ignored) { text("ફોટો ઉપલબ્ધ નથી", 14, MUTED, false); }
                }
                text("──────────────", 14, MUTED, false);
            }
        } catch (Exception ex) { text("પોસ્ટ લોડ થઈ શકી નથી", 14, MUTED, false); }
    }
    private void createRoom() {
        EditText e = new EditText(this); e.setSingleLine(true); e.setHint("રૂમનું નામ");
        LinearLayout wrap = new LinearLayout(this); wrap.setPadding(dp(20), 0, dp(20), 0); wrap.addView(e);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("નવો રૂમ").setView(wrap)
            .setNegativeButton("રદ કરો", null).setPositiveButton("બનાવો", null).create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(w -> {
            String name = e.getText().toString().trim();
            if (name.isEmpty()) { e.setError("રૂમનું નામ લખો"); return; }
            if (rooms.contains(name)) { e.setError("આ નામનો રૂમ પહેલેથી છે"); return; }
            rooms.add(0, name);
            getPreferences(0).edit().putStringSet("rooms", new HashSet<>(rooms)).apply();
            dialog.dismiss(); room(name);
        })); dialog.show();
    }
    private void room(String name) {
        screen = "room"; currentRoom = name; stopMic();
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(0xff17112f);
        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); header.setPadding(dp(14),dp(16),dp(12),dp(8));
        TextView title = new TextView(this); title.setText("‹   " + name + "\n     ID 10086  •  👥 128"); title.setTextColor(Color.WHITE); title.setTextSize(18); title.setTypeface(null,Typeface.BOLD); title.setOnClickListener(v->home()); header.addView(title,new LinearLayout.LayoutParams(0,dp(66),1));
        TextView menu = new TextView(this); menu.setText("⋯"); menu.setTextColor(Color.WHITE); menu.setTextSize(30); menu.setGravity(Gravity.CENTER); menu.setOnClickListener(v->roomMenu()); header.addView(menu,new LinearLayout.LayoutParams(dp(54),dp(54))); root.addView(header);
        TextView notice = new TextView(this); notice.setText("📢  " + roomAnnouncement); notice.setTextColor(0xffffd76a); notice.setTextSize(13); notice.setPadding(dp(18),dp(8),dp(18),dp(12)); root.addView(notice);
        LinearLayout seatsWrap = new LinearLayout(this); seatsWrap.setOrientation(LinearLayout.VERTICAL); seatsWrap.setPadding(dp(8),dp(4),dp(8),dp(8));
        for(int r=0;r<3;r++){ LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER); for(int c=0;c<4;c++){ int n=r*4+c+1; LinearLayout seat=new LinearLayout(this); seat.setOrientation(LinearLayout.VERTICAL); seat.setGravity(Gravity.CENTER); TextView avatar=new TextView(this); avatar.setText(n==mySeat?"👑":"＋"); avatar.setTextSize(n==mySeat?30:26); avatar.setGravity(Gravity.CENTER); avatar.setTextColor(Color.WHITE); avatar.setBackground(background(n==mySeat?0xff7447e8:0xff30264f,40)); seat.addView(avatar,new LinearLayout.LayoutParams(dp(54),dp(54))); TextView label=new TextView(this); label.setText(n==mySeat?displayName:"Seat "+n); label.setTextColor(n==mySeat?Color.WHITE:0xffbdb4d7); label.setTextSize(11); label.setGravity(Gravity.CENTER); seat.addView(label,new LinearLayout.LayoutParams(-1,dp(28))); final int seatNo=n; seat.setOnClickListener(v->seatActions(seatNo)); row.addView(seat,new LinearLayout.LayoutParams(0,dp(92),1)); } seatsWrap.addView(row,new LinearLayout.LayoutParams(-1,dp(92))); } root.addView(seatsWrap);
        ScrollView chatScroll=new ScrollView(this); LinearLayout chat=new LinearLayout(this); chat.setOrientation(LinearLayout.VERTICAL); chat.setPadding(dp(16),dp(8),dp(16),dp(8)); chatScroll.addView(chat); addChat(chat,"System","Welcome to KING Plus voice room 👋"); addChat(chat,"Lily","Hello everyone ✨"); addChat(chat,"Alex","Nice room! 🎵"); root.addView(chatScroll,new LinearLayout.LayoutParams(-1,0,1));
        meter=new TextView(this); meter.setText("Mic off"); meter.setTextColor(0xffc9c0df); meter.setTextSize(12); meter.setGravity(Gravity.CENTER); root.addView(meter,new LinearLayout.LayoutParams(-1,dp(25)));
        LinearLayout controls=new LinearLayout(this); controls.setGravity(Gravity.CENTER); controls.setPadding(dp(8),dp(5),dp(8),dp(12)); String[] icons={"💬\nChat","🎤\nMic","🎁\nGift","🎮\nGame","🚪\nLeave"}; for(int i=0;i<icons.length;i++){ TextView x=new TextView(this); x.setText(icons[i]); x.setTextColor(Color.WHITE); x.setTextSize(12); x.setGravity(Gravity.CENTER); x.setBackground(background(0xff2a2147,18)); final int k=i; x.setOnClickListener(v->{ if(k==0) chatDialog(chat); else if(k==1){ if(recording){stopMic();meter.setText("Mic off");}else requestMic(); } else if(k==2) giftDialog(chat); else if(k==3) roomGames(); else home(); }); LinearLayout.LayoutParams xp=new LinearLayout.LayoutParams(0,dp(58),1); xp.setMargins(dp(3),0,dp(3),0); controls.addView(x,xp);} root.addView(controls); setContentView(root);
    }
    private void addChat(LinearLayout chat,String who,String message){ TextView t=new TextView(this); t.setText(who+":  "+message); t.setTextColor(Color.WHITE); t.setTextSize(14); t.setPadding(dp(10),dp(7),dp(10),dp(7)); chat.addView(t,new LinearLayout.LayoutParams(-1,-2)); }
    private void chatDialog(LinearLayout chat){ final EditText e=new EditText(this); e.setHint("Say something..."); new AlertDialog.Builder(this).setTitle("Room chat").setView(e).setNegativeButton("Cancel",null).setPositiveButton("Send",(d,w)->{String m=e.getText().toString().trim(); if(!m.isEmpty()) addChat(chat,displayName,m);}).show(); }
    private void giftDialog(LinearLayout chat){
        String[] gifts={"🌹 Rose  1","❤️ Heart  5","🍭 Candy  10","🎂 Cake  50","💎 Diamond  100","🚗 Sports Car  500","👑 Crown  999","🎆 Fireworks  1999"};
        int[] prices={1,5,10,50,100,500,999,1999};
        new AlertDialog.Builder(this).setTitle("🎁 Gift Store • Balance "+coinBalance).setItems(gifts,(d,w)->{
            if(coinBalance < prices[w]) { Toast.makeText(this,"Not enough coins",Toast.LENGTH_SHORT).show(); return; }
            coinBalance -= prices[w]; giftCount++; getPreferences(0).edit().putInt("coins",coinBalance).putInt("gift_count",giftCount).apply();
            addChat(chat,displayName,"sent "+gifts[w]); giftEffect(gifts[w]);
        }).setNegativeButton("Close",null).show();
    }
    private void roomGames(){
        final String[] gameNames={"🎲 Ludo Party","🎯 Lucky Dart","🐍 Snake Battle","🏁 Racing","🎁 Lucky Draw"};
        new AlertDialog.Builder(this).setTitle("🎮 Room Games").setItems(gameNames,(d,w)->playMiniGame(gameNames[w])).setNegativeButton("Close",null).show();
    }
    private void playMiniGame(String game){
        String result;
        if(game.contains("Dart")) result="Score: "+(60+(int)(Math.random()*41))+" / 100";
        else if(game.contains("Draw")) result="Reward: "+(10+(int)(Math.random()*91))+" coins";
        else if(game.contains("Racing")) result="Finished #"+(1+(int)(Math.random()*4));
        else if(game.contains("Snake")) result="Battle score: "+(100+(int)(Math.random()*901));
        else result="Ludo table created • Waiting for players";
        new AlertDialog.Builder(this).setTitle(game).setMessage(result).setPositiveButton("Play again",(d,w)->playMiniGame(game)).setNegativeButton("Back",null).show();
    }
    private void giftEffect(String gift){ final Toast t=Toast.makeText(this,"✨  "+gift+"  ✨",Toast.LENGTH_LONG); t.setGravity(Gravity.CENTER,0,0); t.show(); }
    private void seatActions(int seatNo){
        String[] actions = seatNo==mySeat ? new String[]{"🎤 Mic on/off","↔ Change seat","🚪 Leave seat"} : new String[]{"🪑 Take seat","👤 View profile","🛡 Make admin","🔇 Mute seat"};
        new AlertDialog.Builder(this).setTitle("Seat "+seatNo).setItems(actions,(d,w)->{
            if(seatNo==mySeat){ if(w==0){ if(recording) stopMic(); else requestMic(); } else if(w==1) chooseSeat(); else { mySeat=0; Toast.makeText(this,"Seat left",Toast.LENGTH_SHORT).show(); room(currentRoom); } }
            else if(w==0){ if(roomLocked){Toast.makeText(this,"Room is locked",Toast.LENGTH_SHORT).show();return;} mySeat=seatNo; Toast.makeText(this,"You joined Seat "+seatNo,Toast.LENGTH_SHORT).show(); room(currentRoom); }
            else Toast.makeText(this,actions[w],Toast.LENGTH_SHORT).show();
        }).show();
    }
    private void chooseSeat(){ final String[] seats=new String[12]; for(int i=0;i<12;i++) seats[i]="Seat "+(i+1); new AlertDialog.Builder(this).setTitle("Change seat").setItems(seats,(d,w)->{mySeat=w+1; room(currentRoom);}).show(); }

    private void roomMenu(){ String[] items={"ℹ Room info","📢 Announcement","👥 Members","🛡 Admin controls","🔒 Lock / Unlock room","🚩 Report room"}; new AlertDialog.Builder(this).setTitle(currentRoom).setItems(items,(d,w)->{ if(w==0) roomInfo(); else if(w==1) editAnnouncement(); else if(w==2) roomMembers(); else if(w==3) adminControls(); else if(w==4){roomLocked=!roomLocked;Toast.makeText(this,roomLocked?"Room locked":"Room unlocked",Toast.LENGTH_SHORT).show();} else Toast.makeText(this,"Report form opened",Toast.LENGTH_SHORT).show(); }).setNegativeButton("Close",null).show(); }
    private void roomInfo(){ new AlertDialog.Builder(this).setTitle("Room information").setMessage("👑 "+currentRoom+"\nID: 10086\nMembers: 128\nSeats: 12\nCategory: Party\n\n"+roomAnnouncement).setPositiveButton("OK",null).show(); }
    private void editAnnouncement(){ final EditText e=new EditText(this); e.setText(roomAnnouncement); e.setSelectAllOnFocus(true); new AlertDialog.Builder(this).setTitle("Room announcement").setView(e).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{String x=e.getText().toString().trim();if(!x.isEmpty())roomAnnouncement=x;Toast.makeText(this,"Announcement saved",Toast.LENGTH_SHORT).show();room(currentRoom);}).show(); }
    private void roomMembers(){ String[] members={"👑 "+displayName+" • Host","🎵 Lily • Admin","🎮 Alex • Member","💜 Mia • Member","✨ DJ Max • Member"}; new AlertDialog.Builder(this).setTitle("Members • 128").setItems(members,(d,w)->Toast.makeText(this,members[w],Toast.LENGTH_SHORT).show()).setNegativeButton("Close",null).show(); }
    private void adminControls(){ String[] a={"🎤 Open all mics","🔇 Mute all seats","🧹 Clear chat","👥 Manage admins","🚫 Block list","⚙ Room permissions"}; new AlertDialog.Builder(this).setTitle("Admin controls").setItems(a,(d,w)->Toast.makeText(this,a[w],Toast.LENGTH_SHORT).show()).setNegativeButton("Close",null).show(); }

    private void requestMic() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQUEST); return;
        }
        startMic();
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == MIC_REQUEST && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED && "room".equals(screen)) startMic();
        else if (requestCode == MIC_REQUEST) Toast.makeText(this, "માઇક પરવાનગી જરૂરી છે", Toast.LENGTH_SHORT).show();
    }
    private void startMic() {
        stopMic();
        int rate = 16000;
        int min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        if (min <= 0) { Toast.makeText(this, "માઇક ઉપલબ્ધ નથી", Toast.LENGTH_SHORT).show(); return; }
        try {
            recorder = new AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, Math.max(min, 2048));
            if (recorder.getState() != AudioRecord.STATE_INITIALIZED) { stopMic(); return; }
            recorder.startRecording(); recording = true;
            if (meter != null) meter.setText("માઇક ચાલુ છે • બોલીને તપાસો");
            AudioRecord source = recorder;
            meterThread = new Thread(() -> {
                short[] samples = new short[1024];
                while (recording) {
                    int count = source.read(samples, 0, samples.length);
                    if (count <= 0) break;
                    long sum = 0;
                    for (int i = 0; i < count; i++) sum += Math.abs((int)samples[i]);
                    int level = (int)Math.min(10, (sum / count) / 1800);
                    handler.post(() -> { if (recording && meter != null) meter.setText("માઇક ચાલુ છે  " + bars(level)); });
                }
            }); meterThread.start();
        } catch (Exception ex) { stopMic(); Toast.makeText(this, "માઇક શરૂ થઈ શક્યો નથી", Toast.LENGTH_SHORT).show(); }
    }
    private void stopMic() {
        recording = false;
        if (recorder != null) {
            try { recorder.stop(); } catch (Exception ignored) { }
            recorder.release(); recorder = null;
        }
        meterThread = null;
    }
    private String bars(int level) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < 10; i++) result.append(i < level ? '▮' : '▯');
        return result.toString();
    }
    private TextView cardLine(LinearLayout host, String title, String subtitle, Runnable action) {
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16),dp(11),dp(16),dp(11)); card.setBackground(background(0xffffffff,16));
        TextView a=new TextView(this); a.setText(title); a.setTextSize(16); a.setTextColor(0xff202020); a.setTypeface(null,Typeface.BOLD); card.addView(a);
        TextView b=new TextView(this); b.setText(subtitle); b.setTextSize(13); b.setTextColor(0xff888888); b.setPadding(0,dp(4),0,0); card.addView(b);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(70)); lp.setMargins(0,dp(5),0,dp(5)); host.addView(card,lp);
        if(action!=null) card.setOnClickListener(v->action.run()); return a;
    }
    private void messages() {
        screen="messages"; stopMic();
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(0xfff7f7fb);
        TextView h=new TextView(this); h.setText("Messages"); h.setTextSize(25); h.setTextColor(0xff171717); h.setTypeface(null,Typeface.BOLD); h.setGravity(Gravity.CENTER_VERTICAL); h.setPadding(dp(18),dp(18),0,dp(8)); root.addView(h,new LinearLayout.LayoutParams(-1,dp(66)));
        LinearLayout quick=new LinearLayout(this); quick.setGravity(Gravity.CENTER); String[] q={"👤\nFollowers","💜\nFriends","🔔\nNotifications"};
        for(int i=0;i<q.length;i++){ TextView x=new TextView(this); x.setText(q[i]); x.setGravity(Gravity.CENTER); x.setTextSize(14); x.setTextColor(0xff333333); final int k=i; x.setOnClickListener(v->{if(k==0) peoplePage("Followers"); else if(k==1) peoplePage("Friends"); else notifications();}); quick.addView(x,new LinearLayout.LayoutParams(0,dp(82),1)); } root.addView(quick);
        ScrollView sv=new ScrollView(this); LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(14),dp(8),dp(14),dp(16)); sv.addView(list);
        cardLine(list,"👑  KING Plus Official","Welcome to KING Plus • Just now",()->conversation("KING Plus Official"));
        cardLine(list,"🎵  Lily","See you in the music room ✨ • 2m",()->conversation("Lily"));
        cardLine(list,"🎮  Alex","Let's play tonight • 18m",()->conversation("Alex"));
        cardLine(list,"💜  Friends Group","Mia: Hello everyone 👋 • 1h",()->conversation("Friends Group"));
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); addBottomNav(root,3); setContentView(root);
    }
    private void addBottomNav(LinearLayout root,int selected){
        LinearLayout nav=new LinearLayout(this); nav.setGravity(Gravity.CENTER); nav.setBackgroundColor(Color.WHITE); String[] ni={"⌂\nParty","♟\nGame","◇\nDiscover","✉\nMessages","●\nMe"};
        for(int i=0;i<ni.length;i++){TextView n=new TextView(this);n.setText(ni[i]);n.setTextSize(12);n.setGravity(Gravity.CENTER);n.setTextColor(i==selected?0xff8a43ff:0xff777777);final int k=i;n.setOnClickListener(v->{if(k==0)home();else if(k==1)games();else if(k==2)discover();else if(k==3)messages();else profile();});nav.addView(n,new LinearLayout.LayoutParams(0,dp(62),1));} root.addView(nav);
    }

    private void games(){
        screen="games"; stopMic(); LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(0xfff7f7fb);
        TextView h=new TextView(this); h.setText("Game Center"); h.setTextSize(25); h.setTextColor(0xff171717); h.setTypeface(null,Typeface.BOLD); h.setPadding(dp(18),dp(18),0,dp(10)); root.addView(h,new LinearLayout.LayoutParams(-1,dp(66)));
        ScrollView sv=new ScrollView(this); LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(14),dp(8),dp(14),dp(18)); sv.addView(list);
        cardLine(list,"🎲  Ludo Party","2–4 players • Play with room friends",()->playMiniGame("🎲 Ludo Party"));
        cardLine(list,"🎯  Lucky Dart","Aim, score and challenge friends",()->playMiniGame("🎯 Lucky Dart"));
        cardLine(list,"🐍  Snake Battle","Fast multiplayer mini game",()->playMiniGame("🐍 Snake Battle"));
        cardLine(list,"🏁  Racing","Quick race • Room challenge",()->playMiniGame("🏁 Racing"));
        cardLine(list,"🎁  Lucky Draw","Daily rewards and room prizes",()->playMiniGame("🎁 Lucky Draw"));
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); addBottomNav(root,1); setContentView(root);
    }
    private void discover(){
        screen="discover"; stopMic(); LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(0xfff7f7fb);
        TextView h=new TextView(this); h.setText("Discover"); h.setTextSize(25); h.setTextColor(0xff171717); h.setTypeface(null,Typeface.BOLD); h.setPadding(dp(18),dp(18),0,dp(10)); root.addView(h,new LinearLayout.LayoutParams(-1,dp(66)));
        ScrollView sv=new ScrollView(this); LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(14),dp(8),dp(14),dp(18)); sv.addView(list);
        cardLine(list,"📝  Moments","Share posts with the KING Plus community",this::momentsPage);
        cardLine(list,"🔥  Trending Rooms","Popular voice parties right now",()->room("Trending Party"));
        cardLine(list,"🎉  Events","Music nights, games and community events",()->simplePage("Events","🎉 Upcoming KING Plus events will appear here"));
        cardLine(list,"👥  Find Friends","Discover new people in the community",()->peoplePage("Discover People"));
        cardLine(list,"🎵  Music","Live music and singing rooms",()->room("Music Live"));
        cardLine(list,"💜  New & Nearby","Fresh rooms and new creators",()->room("New Friends"));
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); addBottomNav(root,2); setContentView(root);
    }
    private void conversation(String who){
        screen="conversation"; base(who,"Online"); text("Today",13,MUTED,false);
        text(who+":  Hello 👋",16,Color.WHITE,false);
        String key="chat_"+who.replaceAll("[^A-Za-z0-9]","_");
        String saved=getPreferences(0).getString(key,"");
        if(!saved.isEmpty()) for(String m:saved.split("\n")) if(!m.trim().isEmpty()) text(displayName+":  "+m,16,0xffd9caff,false);
        EditText e=input("Write a message…","");
        button("Send",PURPLE,()->{String m=e.getText().toString().trim(); if(!m.isEmpty()){String prev=getPreferences(0).getString(key,""); getPreferences(0).edit().putString(key,prev+m+"\n").apply(); Toast.makeText(this,"Message saved",Toast.LENGTH_SHORT).show(); conversation(who);}});
        button("Back to Messages",CARD,this::messages);
    }
    private void momentsPage(){
        screen="moments"; base("Moments","Share updates with the KING Plus community");
        EditText post=input("What's happening?","");
        button("Post",PURPLE,()->{String m=post.getText().toString().trim(); if(m.isEmpty()){post.setError("Write something first");return;} String old=getPreferences(0).getString("moments",""); getPreferences(0).edit().putString("moments",m+"|||"+old).apply(); momentsPage();});
        String saved=getPreferences(0).getString("moments","");
        if(saved.isEmpty()) text("No posts yet. Create your first Moment ✨",15,MUTED,false);
        else {String[] posts=saved.split("\|\|\|"); for(String m:posts) if(!m.trim().isEmpty()){text("●  "+displayName,15,Color.WHITE,true); text(m,16,Color.WHITE,false); button("♡ Like   💬 Comment",CARD,()->Toast.makeText(this,"Interaction saved locally",Toast.LENGTH_SHORT).show());}}
        button("Back to Discover",CARD,this::discover);
    }
    private void peoplePage(String title){
        screen="people"; base(title,"KING Plus community");
        String[] names={"Lily ✨","Alex 🎮","Mia 💜","DJ Max 🎵","Queen 👑"};
        for(String n:names) button("👤  "+n,CARD,()->userProfile(n));
        button("Back",PURPLE,this::messages);
    }
    private void userProfile(String who){
        screen="user_profile"; base(who,"KING Plus member");
        text("●",54,0xffd9caff,true); text("ID: "+Math.abs(who.hashCode()%900000+100000),14,MUTED,false);
        text("Music • Games • Voice rooms",15,Color.WHITE,false);
        Set<String> following=new HashSet<>(getPreferences(0).getStringSet("following",new HashSet<>()));
        boolean isFollowing=following.contains(who);
        button(isFollowing?"✓ Following":"＋ Follow",PURPLE,()->{Set<String> f=new HashSet<>(getPreferences(0).getStringSet("following",new HashSet<>())); if(f.contains(who))f.remove(who);else f.add(who);getPreferences(0).edit().putStringSet("following",f).apply();userProfile(who);});
        button("✉ Message",CARD,()->conversation(who));
        button("🎤 Invite to Room",CARD,()->Toast.makeText(this,"Room invite created locally",Toast.LENGTH_SHORT).show());
        button("⋮ Safety options",CARD,()->safetyOptions(who));
        button("Back",CARD,()->peoplePage("Discover People"));
    }
    private void safetyOptions(String who){
        String[] a={"🚫 Block / Unblock","⚑ Report user"};
        new AlertDialog.Builder(this).setTitle(who).setItems(a,(d,w)->{if(w==0){Set<String>b=new HashSet<>(getPreferences(0).getStringSet("blocked",new HashSet<>()));boolean blocked;if(b.contains(who)){b.remove(who);blocked=false;}else{b.add(who);blocked=true;}getPreferences(0).edit().putStringSet("blocked",b).apply();Toast.makeText(this,blocked?"User blocked":"User unblocked",Toast.LENGTH_SHORT).show();}else reportDialog(who);}).show();
    }
    private void reportDialog(String who){
        String[] reasons={"Spam","Harassment","Inappropriate content","Fake account","Other"};
        new AlertDialog.Builder(this).setTitle("Report "+who).setItems(reasons,(d,w)->{int count=getPreferences(0).getInt("reports",0)+1;getPreferences(0).edit().putInt("reports",count).apply();Toast.makeText(this,"Report saved for review",Toast.LENGTH_SHORT).show();}).setNegativeButton("Cancel",null).show();
    }
    private void notifications(){ screen="notifications"; base("Notifications",null); text("🎁 Lily sent you a gift",16,Color.WHITE,false); text("👤 Alex started following you",16,Color.WHITE,false); text("🎉 KING Lounge has a new event",16,Color.WHITE,false); button("Back",PURPLE,this::messages); }
    private void sideMenu(){ String[] items={"👤 My Profile","✏ Edit Profile","💜 Friends","👥 Followers","🎒 Backpack","🏆 Level","👑 Rankings","💠 VIP Center","🏠 Family & Agency","💎 Wallet","🔔 Notifications","⚙ Settings","❓ Help & Feedback"}; new AlertDialog.Builder(this).setTitle("KING Plus").setItems(items,(d,w)->{if(w==0)profile();else if(w==1)editProfile();else if(w==2)peoplePage("Friends");else if(w==3)peoplePage("Followers");else if(w==4)backpackPage();else if(w==5)levelPage();else if(w==6)rankingsPage();else if(w==7)vipPage();else if(w==8)familyAgencyPage();else if(w==9)walletPage();else if(w==10)notificationsCenter();else if(w==11)settingsPage();else simplePage("Help & Feedback","KING Plus help and feedback center.");}).setNegativeButton("Close",null).show(); }
    private void editProfile(){
        screen="editProfile"; base("Edit Profile","Update your KING Plus identity");
        EditText name=input("Display name",displayName);
        EditText bio=input("Bio",getPreferences(0).getString("bio","Love music, games and new friends ✨"));
        button("Save changes",PURPLE,()->{String n=name.getText().toString().trim(); if(n.isEmpty()){name.setError("Name required");return;} displayName=n; getPreferences(0).edit().putString("name",n).putString("bio",bio.getText().toString().trim()).apply(); Toast.makeText(this,"Profile updated",Toast.LENGTH_SHORT).show(); profile();});
        button("Back",CARD,this::profile);
    }

    private void walletPage(){
        screen="wallet"; base("My Wallet","KING Plus balance");
        text("💎 "+coinBalance+" Coins",28,Color.WHITE,true); text("Available balance",14,MUTED,false);
        text("🎁 Gifts sent: "+giftCount,16,Color.WHITE,false);
        button("Demo +500 Coins",PURPLE,()->{ coinBalance += 500; getPreferences(0).edit().putInt("coins",coinBalance).apply(); Toast.makeText(this,"500 demo coins added",Toast.LENGTH_SHORT).show(); walletPage(); });
        text("Gift Center",18,Color.WHITE,true);
        button("Open Gift Catalog",CARD,this::giftCatalogPage);
        text("Note: real-money recharge is not enabled in this local build.",13,MUTED,false);
        button("Back",CARD,this::profile);
    }
    private void giftCatalogPage(){
        screen="gift_catalog"; base("Gift Center","Choose gifts for voice rooms");
        String[] names={"🌹 Rose","❤️ Heart","🍭 Candy","🎂 Cake","💎 Diamond","🚗 Sports Car","👑 Crown","🎆 Fireworks"};
        int[] prices={1,5,10,50,100,500,999,1999};
        for(int i=0;i<names.length;i++){ final int k=i; button(names[i]+"   •   "+prices[i]+" coins",CARD,()->new AlertDialog.Builder(this).setTitle(names[k]).setMessage("Gift price: "+prices[k]+" coins\n\nSend gifts from inside a voice room so a recipient/room is selected.").setPositiveButton("OK",null).show()); }
        button("Back to Wallet",CARD,this::walletPage);
    }
    private void backpackPage(){
        screen="backpack"; base("Backpack","Your room items and rewards");
        text("Gift Activity",18,Color.WHITE,true); text("🎁 Sent gifts   ×"+giftCount,17,Color.WHITE,false); text("📥 Received gifts   ×"+receivedGiftCount,17,Color.WHITE,false);
        text("Frames & Effects",18,Color.WHITE,true); text("👑 Royal profile frame",16,MUTED,false); text("✨ Welcome room effect",16,MUTED,false);
        button("Back",CARD,this::profile);
    }
    private void levelPage(){
        screen="level"; base("Level & Achievements","Your KING Plus progress");
        text("🏆 Level 1",30,Color.WHITE,true); text("120 / 500 XP to Level 2",15,MUTED,false);
        text("Achievements",18,Color.WHITE,true); text("🎤 First Voice Room  ✓",16,Color.WHITE,false); text("🎁 First Gift  ✓",16,Color.WHITE,false); text("👥 Make 10 Friends  4/10",16,MUTED,false);
        button("Back",CARD,this::profile);
    }
    private void settingsPage(){
        screen="settings"; base("Settings","Account and app controls");
        text("Account",18,Color.WHITE,true); text("Signed in locally as "+displayName,15,MUTED,false);
        button("Edit Profile",CARD,this::editProfile);
        button("Notifications",CARD,()->Toast.makeText(this,"Notification preferences saved locally",Toast.LENGTH_SHORT).show());
        button("Privacy & Safety",CARD,this::privacySafetyPage);
        button("Log out",0xffb23a48,()->new AlertDialog.Builder(this).setTitle("Log out?").setMessage("Your local KING Plus session will be cleared.").setNegativeButton("Cancel",null).setPositiveButton("Log out",(d,w)->{getPreferences(0).edit().remove("name").apply();displayName="";login();}).show());
        button("Back",PURPLE,this::profile);
    }
    private void privacySafetyPage(){
        screen="privacy"; base("Privacy & Safety","Control your KING Plus experience");
        Set<String> blocked=getPreferences(0).getStringSet("blocked",new HashSet<>());
        text("Blocked users: "+blocked.size(),17,Color.WHITE,true);
        if(blocked.isEmpty()) text("No blocked users",14,MUTED,false); else for(String n:blocked) text("🚫 "+n,15,Color.WHITE,false);
        text("Reports submitted: "+getPreferences(0).getInt("reports",0),15,MUTED,false);
        button("Clear blocked list",CARD,()->{getPreferences(0).edit().remove("blocked").apply();privacySafetyPage();});
        button("Back to Settings",PURPLE,this::settingsPage);
    }
    private void profile() {
        screen="profile"; stopMic();
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(0xfff7f7fb);
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(dp(16),dp(16),dp(12),dp(6)); TextView title=new TextView(this); title.setText("Me"); title.setTextSize(25); title.setTextColor(0xff191919); title.setTypeface(null,Typeface.BOLD); top.addView(title,new LinearLayout.LayoutParams(0,dp(52),1)); TextView menu=new TextView(this); menu.setText("☰"); menu.setTextSize(27); menu.setGravity(Gravity.CENTER); menu.setOnClickListener(v->sideMenu()); top.addView(menu,new LinearLayout.LayoutParams(dp(54),dp(52))); root.addView(top);
        LinearLayout hero=new LinearLayout(this); hero.setOrientation(LinearLayout.VERTICAL); hero.setGravity(Gravity.CENTER); hero.setPadding(dp(12),dp(12),dp(12),dp(12)); TextView av=new TextView(this); av.setText("👑"); av.setTextSize(48); av.setGravity(Gravity.CENTER); av.setBackground(background(0xffeadfff,50)); hero.addView(av,new LinearLayout.LayoutParams(dp(88),dp(88))); TextView nm=new TextView(this); nm.setText(displayName); nm.setTextSize(23); nm.setTextColor(0xff202020); nm.setTypeface(null,Typeface.BOLD); nm.setGravity(Gravity.CENTER); hero.addView(nm); TextView id=new TextView(this); id.setText("ID: 10086   ♢ Lv.1"); id.setTextSize(13); id.setTextColor(0xff777777); id.setGravity(Gravity.CENTER); hero.addView(id); TextView bio=new TextView(this); bio.setText(getPreferences(0).getString("bio","Love music, games and new friends ✨")); bio.setTextSize(13); bio.setTextColor(0xff666666); bio.setGravity(Gravity.CENTER); bio.setPadding(dp(20),dp(6),dp(20),0); hero.addView(bio); root.addView(hero,new LinearLayout.LayoutParams(-1,dp(190)));
        LinearLayout stats=new LinearLayout(this); stats.setGravity(Gravity.CENTER); String[] ss={"128\nFollowing","356\nFollowers","24\nFriends","1.2K\nCharm"}; for(String z:ss){TextView x=new TextView(this);x.setText(z);x.setGravity(Gravity.CENTER);x.setTextSize(14);x.setTextColor(0xff333333);stats.addView(x,new LinearLayout.LayoutParams(0,dp(64),1));} root.addView(stats);
        ScrollView sv=new ScrollView(this); LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(14),dp(5),dp(14),dp(14)); sv.addView(list); cardLine(list,"💎 My Wallet","Coins, diamonds and recharge",this::walletPage); cardLine(list,"🎒 Backpack","Gifts, frames and room items",this::backpackPage); cardLine(list,"🏆 Level & Achievements","Level 1 • Start your KING journey",this::levelPage); cardLine(list,"👑 Rankings","Weekly stars and top gifters",this::rankingsPage); cardLine(list,"💠 VIP Center","Badges, frames and entrance effects",this::vipPage); cardLine(list,"🏠 Family & Agency","Family members, agency and host tools",this::familyAgencyPage); cardLine(list,"📅 Daily Check-in","Claim a daily local reward",this::dailyCheckInPage); cardLine(list,"🏅 Missions","Daily activity missions and progress",this::missionsPage); cardLine(list,"⚙ Settings","Account, privacy and notifications",this::settingsPage); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); addBottomNav(root,4); setContentView(root);
    }
    private void rankingsPage(){
        screen="rankings"; base("Rankings","Community leaderboard preview");
        text("👑 Weekly Stars",20,Color.WHITE,true);
        String[] stars={"🥇 Lily   •  28.4K charm","🥈 Alex   •  21.7K charm","🥉 Mia   •  18.9K charm","4   KING Host   •  12.6K charm","5   Music Fan   •  9.8K charm"};
        for(String x:stars) button(x,CARD,()->Toast.makeText(this,"Profile preview opened",Toast.LENGTH_SHORT).show());
        text("🎁 Top Gifters",20,Color.WHITE,true);
        text("1. RoyalKing  15.2K coins     2. Moon  11.8K     3. DJ Max  9.4K",14,MUTED,false);
        text("Rankings are demo/local until live server statistics are connected.",13,MUTED,false);
        button("Back to Profile",CARD,this::profile);
    }
    private void vipPage(){
        screen="vip"; base("VIP Center","KING Plus membership preview");
        text("💠 VIP 1",28,Color.WHITE,true);
        text("Unlock profile badge, room entrance effect, special frame and VIP identity styling.",15,MUTED,false);
        button("👑 VIP Badge Preview",CARD,()->Toast.makeText(this,"VIP badge preview",Toast.LENGTH_SHORT).show());
        button("✨ Entrance Effect Preview",CARD,()->Toast.makeText(this,"Entrance effect preview",Toast.LENGTH_SHORT).show());
        button("🖼 Profile Frame Preview",CARD,()->Toast.makeText(this,"VIP frame preview",Toast.LENGTH_SHORT).show());
        text("No real purchase is enabled in this prototype.",13,MUTED,false);
        button("Back to Profile",CARD,this::profile);
    }
    private void familyAgencyPage(){
        screen="family_agency"; base("Family & Agency","Community and host center");
        text("🏠 KING Family",24,Color.WHITE,true);
        text("Create or join a family, view members and keep a local family profile.",14,MUTED,false);
        String family=getPreferences(0).getString("family_name","Not joined");
        text("Current family: "+family,16,Color.WHITE,true);
        button("Create Family",PURPLE,()->{
            final EditText name=new EditText(this); name.setHint("Family name");
            new AlertDialog.Builder(this).setTitle("Create Family").setView(name).setNegativeButton("Cancel",null).setPositiveButton("Create",(d,w)->{
                String n=name.getText().toString().trim(); if(n.isEmpty()) n="KING Family";
                getPreferences(0).edit().putString("family_name",n).apply(); Toast.makeText(this,"Family created",Toast.LENGTH_SHORT).show(); familyAgencyPage();
            }).show();
        });
        button("Family Members",CARD,()->new AlertDialog.Builder(this).setTitle("Family Members").setItems(new String[]{"👑 "+displayName+"  • Owner","🎤 Lily  • Host","💜 Alex  • Member","🎮 Mia  • Member"},null).setPositiveButton("Close",null).show());
        text("🎙 Host Agency",20,Color.WHITE,true);
        text("Agency tools are a local preview until verification and server-side host management are connected.",14,MUTED,false);
        button("Host Application",CARD,()->new AlertDialog.Builder(this).setTitle("Host Application").setMessage("Application saved locally for prototype testing.").setPositiveButton("Submit",(d,w)->{getPreferences(0).edit().putBoolean("host_application",true).apply();Toast.makeText(this,"Application saved",Toast.LENGTH_SHORT).show();}).setNegativeButton("Cancel",null).show());
        button("Agency Dashboard",CARD,()->simplePage("Agency Dashboard","Hosts: 4\nActive rooms: 2\nThis is demo/local data until the backend is connected."));
        button("Back to Profile",CARD,this::profile);
    }
    private void dailyCheckInPage(){
        screen="checkin"; base("Daily Check-in","Local reward preview");
        java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US);
        String today=f.format(new java.util.Date());
        android.content.SharedPreferences p=getPreferences(0);
        boolean claimed=today.equals(p.getString("checkin_day",""));
        text(claimed ? "✅ Today's reward already claimed" : "🎁 Today's reward: 100 coins",18,Color.WHITE,true);
        button(claimed ? "Claimed" : "Claim 100 coins", claimed ? CARD : PURPLE, ()->{
            if(today.equals(p.getString("checkin_day",""))){ Toast.makeText(this,"Already claimed today",Toast.LENGTH_SHORT).show(); return; }
            int coins=p.getInt("coins",1000)+100; p.edit().putInt("coins",coins).putString("checkin_day",today).apply();
            Toast.makeText(this,"100 coins added",Toast.LENGTH_SHORT).show(); dailyCheckInPage();
        });
        text("Come back each day to continue your KING Plus activity streak.",14,MUTED,false);
        button("Back to Profile",CARD,this::profile);
    }
    private void missionsPage(){
        screen="missions"; base("Missions","Daily activity progress");
        String[] missions={"🎤 Join a voice room   0/1","💬 Send a room message   0/3","🎁 Send a gift   0/1","👤 Visit a profile   0/2","🎮 Open Game Center   0/1"};
        for(String m:missions) button(m,CARD,()->Toast.makeText(this,"Mission progress is stored locally in this prototype",Toast.LENGTH_SHORT).show());
        text("Mission rewards are demo/local until the online account backend is connected.",13,MUTED,false);
        button("Back to Profile",CARD,this::profile);
    }

    @Override public void onBackPressed() {
        if ("login".equals(screen) || "home".equals(screen)) super.onBackPressed(); else home();
    }
    @Override protected void onPause() { super.onPause(); stopMic(); }
    @Override protected void onDestroy() { stopMic(); super.onDestroy(); }
    private void notificationsCenter(){
        screen="notifications"; base("Notifications","Activity from your KING Plus community");
        String[] notes={"👑 Welcome to KING Plus","💜 Lily followed you","🎁 Alex sent a Rose in KING Lounge","🎮 Game Talk invited you to play","🎤 Music & Friends is live now"};
        for(String n:notes) button(n,CARD,()->Toast.makeText(this,"Opened",Toast.LENGTH_SHORT).show());
        button("Mark all as read",PURPLE,()->{getPreferences(0).edit().putBoolean("notifications_read",true).apply();Toast.makeText(this,"All notifications marked as read",Toast.LENGTH_SHORT).show();});
        button("Back to Messages",CARD,this::messages);
    }
    private void searchCommunity(){
        screen="search"; base("Search","Find rooms and people");
        EditText q=input("Search KING Plus…","");
        button("Search",PURPLE,()->{String x=q.getText().toString().trim(); if(x.isEmpty()){q.setError("Type a name or room");return;} new AlertDialog.Builder(this).setTitle("Results for “"+x+"”").setItems(new String[]{"🎤 "+x+" Room","👤 "+x+" User","✨ Explore similar rooms"},(d,w)->{if(w==0)room(x+" Room");else Toast.makeText(this,"Result opened",Toast.LENGTH_SHORT).show();}).show();});
        text("Try: Music, Friends, Game, KING",13,MUTED,false);
        button("Back",CARD,this::home);
    }
    private void createRoomDialog(){
        final EditText name=new EditText(this); name.setHint("Room name"); name.setSingleLine(true);
        new AlertDialog.Builder(this).setTitle("Create Party Room").setMessage("Create a local room preview. Online room sync will be connected with the backend.").setView(name).setNegativeButton("Cancel",null).setPositiveButton("Create",(d,w)->{String x=name.getText().toString().trim();if(x.isEmpty())x=displayName+"'s Room";if(!rooms.contains(x)) rooms.add(0,x); Set<String> savedRooms=new HashSet<>(rooms); savedRooms.remove("Music & Friends"); savedRooms.remove("KING Lounge"); savedRooms.remove("Game Talk"); getPreferences(0).edit().putStringSet("rooms",savedRooms).apply(); room(x);}).show();
    }

}
